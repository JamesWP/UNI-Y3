//
//  Consts.h
//  Particals
//
//  Created by James Peach on 19/10/2015.
//  Copyright © 2015 James Peach. All rights reserved.
//

#ifndef Consts_h
#define Consts_h

#define WIDTH 800
#define HEIGHT 600

#include "EngineConfig.hpp"

extern EngineConfig conf;

#endif /* Consts_h */
